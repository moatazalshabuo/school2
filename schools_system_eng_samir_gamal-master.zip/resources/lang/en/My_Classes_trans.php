<?php

return [

    'title_page' => 'Classes',
    'List_classes' => 'List Classes',
    'add_class' => 'add class',
    'edit_class'=> 'Edit Class',
    'delete_class'=> 'Delete Class',
    'delete_checkbox'=> 'Delete Selected',
    'Search_By_Grade'=> 'Search By Grade Name',
    'Warning_Grade'=> 'هل انت متاكد من عملية الحذف ؟',
    'submit' => 'submit',
    'required_ar'=>'Please Enter The class Name in Arabic',
    'required_en'=>'Please Enter The class Name in English',
    'Name_class_en'=>'Name class en',
    'Name_Grade'=>'Name Grade',
    'add_row'=>'add row',
    'delete_row'=>'Delete row',
    'Processes'=>'Processes',
    'Edit'=>'Edit',
    'Delete'=>'Delete',
    'delete_Class_Error'=>'The Class cannot be Deleted because it contains Sections',
    'Close' => 'Close',



];

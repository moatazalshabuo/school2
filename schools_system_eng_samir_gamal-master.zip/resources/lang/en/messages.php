<?php

return [
    'success'=>'Data has been saved successfully',
    'Update'=>'Data has been Updated successfully',
    'Delete'=>'Data has been Deleted successfully',

];

<?php

return [

    'Dashboard'=>'Dashboard',
    'Dashboard_page'=>'Dashboard',
    'Main_title' => 'MoraSoft School Management Program',
    'Programname' => 'MoraSoft School Management Program',
    'change_language'=>'language',
    'Grades'=>'Grades',
    'Grades_list'=>'Grades List',
    'classes'=>'Classes',
    'List_classes' => 'List Classes',
    'sections'=>'Sections',
    'List_sections'=>'List Sections',
    'students'=>'Students',
    'add_student'=>'Add student',
    'list_students'=>'list Students',
    'Students_Promotions'=>'Students Promotions',
    'information_student'=>'Information Students',
    'Students_upgrade'=>'Students Upgrade',
    'Graduate_students'=>'Graduate Students',
    'Teachers'=>'Teachers',
    'List_Teachers' => 'List Teachers',
    'Parents'=>'Parents',
    'Add_Parent'=>'Add Parent',
    'List_Parents'=>'List Parents',
    'Accounts'=>'Accounts',
    'Attendance'=>'Attendance',
    'Exams'=>'Exams',
    'library'=>'Library',
    'Onlineclasses'=>'Online classes',
    'Settings'=>'Settings',
    'Users'=>'Users',
    'Copyright' => 'Copyright',
    'Name_Programer' => 'SamirGamal MoraSoft All Rights Reserved'


];

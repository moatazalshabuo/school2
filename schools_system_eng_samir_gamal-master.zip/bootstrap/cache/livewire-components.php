<?php return array (
  'add-parent' => 'App\\Http\\Livewire\\AddParent',
  'calendar' => 'App\\Http\\Livewire\\Calendar',
  'calendar-student' => 'App\\Http\\Livewire\\CalendarStudent',
  'show-question' => 'App\\Http\\Livewire\\ShowQuestion',
);
<html class="no-js" lang="zxx" dir="rtl">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body data-spy="scroll" data-target=".navigation_area" style="font-family: 'Cairo', sans-serif;">

<!--~~~~~ Start Preloader Area ~~~~~-->
<div id="preloader">
    <div class="loader_line"></div>
</div>
<!--~./ end prealoader area ~-->

<div class="site_wrapper bg_white">
    <!--~~~~~ Start Contact Area ~~~~~-->
    <section id="contact" class="contact_area bg_gray section_scroll pt-110" data-scroll-index="6">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title_area text-center pb-10">
                        <h2 style="font-family: 'Cairo', sans-serif;">الاشتراك في كورس برنامج المستشفيات</h2>
                        <h2 style="font-family: 'Cairo'; color: red;">تم اغلاق باب الحجز سيتم الاعلان قريبا </h2>
                    </div>
                    <?php if(session()->has('Error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('Error')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="contact_form_area bg_white mt-110">










































































































































































































































































        </div>
    </section>
    <!--~./ end contact area ~-->
</div>
<!--~~/. end site wrapper ~~-->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH E:\project_laravel\schools_system_eng_samir_gamal-master\resources\views/pages/Fees/index.blade.php ENDPATH**/ ?>
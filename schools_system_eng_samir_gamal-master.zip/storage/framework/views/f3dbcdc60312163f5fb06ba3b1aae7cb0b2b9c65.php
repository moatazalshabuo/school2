<?php $__env->startSection('css'); ?>
    <?php echo toastr_css(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(trans('Sections_trans.title_page')); ?>: الحضور والغياب
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
    <?php echo e(trans('Sections_trans.title_page')); ?>: الحضور والغياب
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <a class="button x-small" href="#" data-toggle="modal" data-target="#exampleModal">
                        <?php echo e(trans('Sections_trans.add_section')); ?></a>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>

                <div class="card card-statistics h-100">
                    <div class="card-body">
                        <div class="accordion gray plus-icon round">

                            <?php $__currentLoopData = $Grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="acd-group">
                                    <a href="#" class="acd-heading"><?php echo e($Grade->Name); ?></a>
                                    <div class="acd-des">

                                        <div class="row">
                                            <div class="col-xl-12 mb-30">
                                                <div class="card card-statistics h-100">
                                                    <div class="card-body">
                                                        <div class="d-block d-md-flex justify-content-between">
                                                            <div class="d-block">
                                                            </div>
                                                        </div>
                                                        <div class="table-responsive mt-15">
                                                            <table class="table center-aligned-table mb-0">
                                                                <thead>
                                                                <tr class="text-dark">
                                                                    <th>#</th>
                                                                    <th><?php echo e(trans('Sections_trans.Name_Section')); ?>

                                                                    </th>
                                                                    <th><?php echo e(trans('Sections_trans.Name_Class')); ?></th>
                                                                    <th><?php echo e(trans('Sections_trans.Status')); ?></th>
                                                                    <th><?php echo e(trans('Sections_trans.Processes')); ?></th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php $i = 0; ?>
                                                                <?php $__currentLoopData = $Grade->Sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_Sections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <?php $i++; ?>
                                                                        <td><?php echo e($i); ?></td>
                                                                        <td><?php echo e($list_Sections->Name_Section); ?></td>
                                                                        <td><?php echo e($list_Sections->My_classs->Name_Class); ?></td>
                                                                        <td>
                                                                            <label class="badge badge-<?php echo e($list_Sections->Status == 1 ? 'success':'danger'); ?>"><?php echo e($list_Sections->Status == 1 ? 'نشط':'غير نشط'); ?></label>
                                                                        </td>

                                                                        <td>
                                                                            <a href="<?php echo e(route('Attendance.show',$list_Sections->id)); ?>" class="btn btn-warning btn-sm" role="button" aria-pressed="true">قائمة الطلاب</a>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        <!-- row closed -->
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('js'); ?>
            <?php echo toastr_js(); ?>
            <?php echo app('toastr')->render(); ?>
            <script>
                $(document).ready(function () {
                    $('select[name="Grade_id"]').on('change', function () {
                        var Grade_id = $(this).val();
                        if (Grade_id) {
                            $.ajax({
                                url: "<?php echo e(URL::to('classes')); ?>/" + Grade_id,
                                type: "GET",
                                dataType: "json",
                                success: function (data) {
                                    $('select[name="Class_id"]').empty();
                                    $.each(data, function (key, value) {
                                        $('select[name="Class_id"]').append('<option value="' + key + '">' + value + '</option>');
                                    });
                                },
                            });
                        } else {
                            console.log('AJAX load did not work');
                        }
                    });
                });

            </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_laravel\schools_system_eng_samir_gamal-master\resources\views/pages/Attendance/Sections.blade.php ENDPATH**/ ?>